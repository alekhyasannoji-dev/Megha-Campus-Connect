'use server';
/**
 * @fileOverview An AI-powered chatbot assistant for answering frequently asked questions about the institution.
 *
 * - chatbotFAQAnswerer - A function that handles answering a user's question.
 * - ChatbotFAQAnswererInput - The input type for the chatbotFAQAnswerer function.
 * - ChatbotFAQAnswererOutput - The return type for the chatbotFAQAnswerer function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ChatbotFAQAnswererInputSchema = z.object({
  question: z.string().describe('The question the user is asking about the institution, admissions, courses, or campus facilities.'),
  language: z.string().optional().default('English').describe('The language in which the response should be provided.'),
});
export type ChatbotFAQAnswererInput = z.infer<typeof ChatbotFAQAnswererInputSchema>;

const ChatbotFAQAnswererOutputSchema = z.object({
  answer: z.string().describe('The AI-generated answer to the user\'s question.'),
});
export type ChatbotFAQAnswererOutput = z.infer<typeof ChatbotFAQAnswererOutputSchema>;

/**
 * Server Action to answer campus FAQs using Genkit.
 */
export async function chatbotFAQAnswerer(input: ChatbotFAQAnswererInput): Promise<ChatbotFAQAnswererOutput> {
  try {
    return await chatbotFAQAnswererFlow(input);
  } catch (error) {
    console.error("Genkit Flow Error:", error);
    throw error;
  }
}

const chatbotFAQPrompt = ai.definePrompt({
  name: 'chatbotFAQPrompt',
  input: {schema: ChatbotFAQAnswererInputSchema},
  output: {schema: ChatbotFAQAnswererOutputSchema},
  prompt: `You are a helpful and knowledgeable campus assistant for Megha Campus Connect. 

Your goal is to:
1. Respond to greetings (like "hi", "hello", "hey") in a friendly, welcoming manner.
2. Provide concise and accurate answers to questions about the institution, admissions, courses, and campus facilities.
3. IMPORTANT: You MUST respond in the following language: {{{language}}}.
4. If a question is simple or a greeting, answer it directly without redirection.
5. If a question is completely unrelated to campus life or education, politely answer it if possible, or guide the user back to how you can help them with campus matters.
6. Maintain a professional yet approachable tone.

Question: {{{question}}}
Answer:`,
});

const chatbotFAQAnswererFlow = ai.defineFlow(
  {
    name: 'chatbotFAQAnswererFlow',
    inputSchema: ChatbotFAQAnswererInputSchema,
    outputSchema: ChatbotFAQAnswererOutputSchema,
  },
  async (input) => {
    const {output} = await chatbotFAQPrompt(input);
    
    if (!output || !output.answer) {
      const fallback = {
        'English': "I'm sorry, I'm having a little trouble thinking right now. Could you please try asking that again?",
        'Hindi': "क्षमा करें, मुझे अभी सोचने में थोड़ी कठिनाई हो रही है। क्या आप कृपया फिर से पूछ सकते हैं?",
        'Spanish': "Lo siento, tengo un poco de dificultad para pensar en este momento. ¿Podrías intentar preguntar de nuevo?",
        'French': "Désolé, j'ai un peu de mal à réfléchir en ce moment. Pourriez-vous s'il vous plaît essayer de redemander ?"
      }[input.language || 'English'] || "I'm sorry, I'm having a little trouble thinking right now.";

      return { answer: fallback };
    }
    
    return output;
  }
);

import { config } from 'dotenv';
config();

import '@/ai/flows/chatbot-faq-answerer.ts';
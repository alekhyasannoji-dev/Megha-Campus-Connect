export const firebaseConfig = {
  "projectId": "studio-5234368835-79154",
  "appId": "1:882374122048:web:0378708e693ebcfbdb5da5",
  "apiKey": "AIzaSyAi9r8brkLVTHL9mQDU1byHi6JloEHDrbI",
  "authDomain": "studio-5234368835-79154.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "882374122048"
};

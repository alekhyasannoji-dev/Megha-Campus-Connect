
"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { 
  LayoutDashboard, 
  Megaphone, 
  BookOpen, 
  MessageSquare, 
  User, 
  LogOut,
  GraduationCap,
  Calendar,
  ClipboardList,
  Star
} from "lucide-react"
import { 
  Sidebar, 
  SidebarContent, 
  SidebarFooter, 
  SidebarHeader, 
  SidebarMenu, 
  SidebarMenuItem, 
  SidebarMenuButton,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent
} from "@/components/ui/sidebar"
import { cn } from "@/lib/utils"

const navItems = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { name: "Announcements", href: "/dashboard/announcements", icon: Megaphone },
  { name: "Events", href: "/dashboard/events", icon: Calendar },
  { name: "My Registrations", href: "/dashboard/registrations", icon: ClipboardList },
  { name: "Academics", href: "/dashboard/academics", icon: BookOpen },
  { name: "Smart Assistant", href: "/dashboard/assistant", icon: MessageSquare },
  { name: "My Profile", href: "/dashboard/profile", icon: User },
  { name: "Feedback", href: "/dashboard/feedback", icon: Star },
]

export function DashboardSidebar() {
  const pathname = usePathname()

  return (
    <Sidebar variant="inset" collapsible="icon">
      <SidebarHeader className="p-4">
        <Link href="/dashboard" className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <GraduationCap className="h-6 w-6" />
          </div>
          <div className="flex flex-col overflow-hidden transition-all group-data-[collapsible=icon]:w-0">
            <span className="text-sm font-bold leading-none">Megha Campus</span>
            <span className="text-xs text-muted-foreground">Student Portal</span>
          </div>
        </Link>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="group-data-[collapsible=icon]:hidden px-4 mb-2">Main Menu</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="px-2">
              {navItems.map((item) => (
                <SidebarMenuItem key={item.name}>
                  <SidebarMenuButton
                    asChild
                    isActive={pathname === item.href}
                    tooltip={item.name}
                    className={cn(
                      "hover:bg-primary/5 hover:text-primary transition-colors py-6",
                      pathname === item.href && "bg-primary/10 text-primary font-semibold"
                    )}
                  >
                    <Link href={item.href}>
                      <item.icon className="h-5 w-5" />
                      <span>{item.name}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild variant="outline" className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10">
              <Link href="/login">
                <LogOut className="h-5 w-5" />
                <span className="group-data-[collapsible=icon]:hidden">Logout</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  )
}

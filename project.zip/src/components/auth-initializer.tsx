'use client';

import { useEffect } from 'react';
import { useUser, useAuth } from '@/firebase';
import { initiateAnonymousSignIn } from '@/firebase/non-blocking-login';

/**
 * AuthInitializer is a silent component that ensures an anonymous session
 * is established as soon as the user enters the dashboard area.
 * This prevents "Session Initializing" errors when performing Firestore operations.
 */
export function AuthInitializer() {
  const { user, isUserLoading } = useUser();
  const auth = useAuth();

  useEffect(() => {
    // If auth state is determined and no user exists, initiate anonymous sign-in
    if (!isUserLoading && !user) {
      initiateAnonymousSignIn(auth);
    }
  }, [user, isUserLoading, auth]);

  return null;
}

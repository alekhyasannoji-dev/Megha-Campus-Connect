"use client"

import { useState } from "react"
import { useFirestore, useUser, useAuth } from "@/firebase"
import { collection } from "firebase/firestore"
import { addDocumentNonBlocking } from "@/firebase/non-blocking-updates"
import { initiateAnonymousSignIn } from "@/firebase/non-blocking-login"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Calendar as CalendarIcon, Image as ImageIcon, Sparkles, Loader2, AlertCircle } from "lucide-react"

interface AddEventDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function AddEventDialog({ open, onOpenChange }: AddEventDialogProps) {
  const { firestore } = useFirestore()
  const auth = useAuth()
  const { user, isUserLoading } = useUser()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const [formData, setFormData] = useState({
    name: "",
    date: "",
    description: "",
    imageUrl: ""
  })

  const validate = () => {
    const newErrors: Record<string, string> = {}
    if (!formData.name.trim()) newErrors.name = "Title required"
    if (!formData.date) newErrors.date = "Date required"
    if (!formData.description.trim()) newErrors.description = "Description required"
    if (!formData.imageUrl.trim()) newErrors.imageUrl = "Image URL required"
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // 1. Client-side Validation
    if (!validate()) {
      toast({
        variant: "destructive",
        title: "Check Required Fields",
        description: "Please complete all fields to publish your event.",
      })
      return
    }

    // 2. Auth & Service Check
    if (!firestore || !user) {
      if (!isUserLoading) {
        initiateAnonymousSignIn(auth);
      }
      toast({
        variant: "destructive",
        title: "Session Initializing",
        description: "Connecting to secure server. Please try again in a moment.",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const eventRef = collection(firestore, "events")

      // 3. Persistent Storage (Firestore)
      addDocumentNonBlocking(eventRef, {
        name: formData.name,
        date: formData.date,
        description: formData.description,
        imageUrl: formData.imageUrl,
        createdBy: user.uid,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      })

      // 4. Success Path (Optimistic UI)
      toast({
        title: "Event Published Successfully",
        description: `${formData.name} is now live on the campus feed!`,
      })
      
      // Reset form
      setFormData({ name: "", date: "", description: "", imageUrl: "" })
      setErrors({})
      onOpenChange(false)
    } catch (error) {
      console.error("Critical Failure Publishing Event:", error)
      toast({
        variant: "destructive",
        title: "Publishing Failed",
        description: "An unexpected error occurred. Please refresh and try again.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] rounded-3xl p-0 overflow-hidden border-none shadow-2xl z-[100]">
        <div className="bg-primary p-6 text-primary-foreground">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black flex items-center gap-2">
              Publish New Event <Sparkles className="h-6 w-6" />
            </DialogTitle>
            <DialogDescription className="text-primary-foreground/80 font-medium">
              Fill in the details below to host your event.
            </DialogDescription>
          </DialogHeader>
        </div>
        
        <form onSubmit={handleFormSubmit} className="p-6 space-y-5 bg-white">
          <div className="space-y-2">
            <Label htmlFor="event-name" className="text-xs font-bold uppercase tracking-widest text-muted-foreground flex justify-between">
              Event Title {errors.name && <span className="text-red-500 lowercase font-medium flex items-center gap-1"><AlertCircle className="h-3 w-3" /> {errors.name}</span>}
            </Label>
            <Input 
              id="event-name" 
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g. Annual Tech Symposium" 
              className={`h-12 rounded-xl border-secondary focus:ring-primary/20 ${errors.name ? 'border-red-300 bg-red-50/10' : ''}`}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="event-date" className="text-xs font-bold uppercase tracking-widest text-muted-foreground flex justify-between">
              Date & Time {errors.date && <span className="text-red-500 lowercase font-medium flex items-center gap-1"><AlertCircle className="h-3 w-3" /> {errors.date}</span>}
            </Label>
            <div className="relative">
              <CalendarIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                id="event-date" 
                type="datetime-local" 
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className={`pl-10 h-12 rounded-xl border-secondary focus:ring-primary/20 ${errors.date ? 'border-red-300 bg-red-50/10' : ''}`}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="event-desc" className="text-xs font-bold uppercase tracking-widest text-muted-foreground flex justify-between">
              Description {errors.description && <span className="text-red-500 lowercase font-medium flex items-center gap-1"><AlertCircle className="h-3 w-3" /> {errors.description}</span>}
            </Label>
            <Textarea 
              id="event-desc" 
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Provide a short overview of the event..." 
              className={`rounded-xl border-secondary focus:ring-primary/20 resize-none ${errors.description ? 'border-red-300 bg-red-50/10' : ''}`}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="event-image" className="text-xs font-bold uppercase tracking-widest text-muted-foreground flex justify-between">
              Cover Image URL {errors.imageUrl && <span className="text-red-500 lowercase font-medium flex items-center gap-1"><AlertCircle className="h-3 w-3" /> {errors.imageUrl}</span>}
            </Label>
            <div className="relative">
              <ImageIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                id="event-image" 
                type="url" 
                value={formData.imageUrl}
                onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                placeholder="https://picsum.photos/seed/event/600/400" 
                className={`pl-10 h-12 rounded-xl border-secondary focus:ring-primary/20 ${errors.imageUrl ? 'border-red-300 bg-red-50/10' : ''}`}
              />
            </div>
          </div>

          <DialogFooter className="pt-2">
            <Button 
              type="submit" 
              className="w-full h-14 rounded-2xl font-black text-lg shadow-xl shadow-primary/20 hover:scale-[1.01] transition-transform active:scale-95 bg-primary"
              disabled={isSubmitting || isUserLoading}
            >
              {isUserLoading ? (
                <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Connecting...</>
              ) : isSubmitting ? (
                <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Publishing...</>
              ) : "Publish Event"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

"use client"

import { useState } from "react"
import { useFirestore, useUser } from "@/firebase"
import { collection } from "firebase/firestore"
import { addDocumentNonBlocking } from "@/firebase/non-blocking-updates"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { CheckCircle2, User, Mail, Phone, GraduationCap, Building } from "lucide-react"

interface RegisterEventDialogProps {
  event: {
    id: string
    name: string
    createdBy: string
  }
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function RegisterEventDialog({ event, open, onOpenChange }: RegisterEventDialogProps) {
  const { firestore } = useFirestore()
  const { user } = useUser()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)

  const [formData, setFormData] = useState({
    registrantName: "",
    rollNumber: "",
    branch: "",
    year: "",
    email: "",
    phoneNumber: ""
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !firestore) return

    setIsLoading(true)
    const registrationsRef = collection(firestore, "events", event.id, "registrations")

    try {
      addDocumentNonBlocking(registrationsRef, {
        ...formData,
        eventId: event.id,
        userId: user.uid,
        eventCreatorId: event.createdBy, // Crucial for security rules logic
        registrationDate: new Date().toISOString(),
        year: parseInt(formData.year) || 0
      })

      toast({
        title: "Registration Successful!",
        description: `You are now registered for ${event.name}.`,
      })
      
      onOpenChange(false)
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Registration Failed",
        description: "Something went wrong. Please try again.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[550px] rounded-3xl overflow-hidden p-0">
        <div className="bg-primary p-8 text-primary-foreground">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black mb-2">Event Registration</DialogTitle>
            <DialogDescription className="text-primary-foreground/80 font-medium">
              Registering for: <span className="text-white font-bold">{event.name}</span>
            </DialogDescription>
          </DialogHeader>
        </div>
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="registrantName" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Full Name</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  id="registrantName" 
                  required 
                  value={formData.registrantName}
                  onChange={(e) => setFormData({ ...formData, registrantName: e.target.value })}
                  placeholder="Aryan Sharma" 
                  className="pl-10 h-11 border-secondary rounded-xl"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="rollNumber" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Roll Number</Label>
              <div className="relative">
                <GraduationCap className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  id="rollNumber" 
                  required 
                  value={formData.rollNumber}
                  onChange={(e) => setFormData({ ...formData, rollNumber: e.target.value })}
                  placeholder="20241001" 
                  className="pl-10 h-11 border-secondary rounded-xl"
                />
              </div>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="branch" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Branch</Label>
              <div className="relative">
                <Building className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  id="branch" 
                  required 
                  value={formData.branch}
                  onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                  placeholder="Computer Science" 
                  className="pl-10 h-11 border-secondary rounded-xl"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="year" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Academic Year</Label>
              <Input 
                id="year" 
                type="number" 
                required 
                value={formData.year}
                onChange={(e) => setFormData({ ...formData, year: e.target.value })}
                placeholder="3" 
                className="h-11 border-secondary rounded-xl"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Email Address</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                id="email" 
                type="email" 
                required 
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="aryan@megha.edu" 
                className="pl-10 h-11 border-secondary rounded-xl"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="phoneNumber" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Phone Number</Label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                id="phoneNumber" 
                required 
                value={formData.phoneNumber}
                onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                placeholder="+91 98765 43210" 
                className="pl-10 h-11 border-secondary rounded-xl"
              />
            </div>
          </div>

          <DialogFooter className="pt-2">
            <Button 
              type="submit" 
              disabled={isLoading}
              className="w-full h-12 rounded-xl font-bold shadow-lg shadow-primary/20 flex items-center gap-2"
            >
              {isLoading ? "Registering..." : (
                <>Confirm Registration <CheckCircle2 className="h-5 w-5" /></>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
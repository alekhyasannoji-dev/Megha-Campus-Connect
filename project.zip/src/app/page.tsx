
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { PlaceHolderImages } from '@/app/lib/placeholder-images';
import { GraduationCap, ShieldCheck, Users, Zap, ArrowRight, CheckCircle } from 'lucide-react';

export default function Home() {
  const heroImage = PlaceHolderImages.find(img => img.id === 'hero-campus');

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground font-body selection:bg-primary/20">
      <header className="px-6 lg:px-12 h-20 flex items-center border-b bg-white/70 backdrop-blur-xl sticky top-0 z-50">
        <Link className="flex items-center justify-center gap-2" href="/">
          <div className="bg-primary p-2 rounded-xl shadow-lg shadow-primary/20">
            <GraduationCap className="h-6 w-6 text-primary-foreground" />
          </div>
          <span className="font-headline font-extrabold text-2xl tracking-tight text-primary">Megha Campus Connect</span>
        </Link>
        <nav className="ml-auto flex items-center gap-4 sm:gap-8">
          <Link className="text-sm font-semibold text-muted-foreground hover:text-primary transition-colors" href="/login">
            Login
          </Link>
          <Button asChild className="rounded-full px-6 bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20">
            <Link href="/register">Join Now</Link>
          </Button>
        </nav>
      </header>

      <main className="flex-1">
        <section className="relative w-full py-16 md:py-24 lg:py-32 xl:py-40">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="grid gap-12 lg:grid-cols-2 lg:gap-16 items-center">
              <div className="flex flex-col justify-center space-y-8 animate-in fade-in slide-in-from-left-4 duration-700">
                <div className="space-y-4">
                  <div className="inline-flex items-center rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-sm font-semibold text-primary">
                    <span className="flex h-2 w-2 rounded-full bg-primary mr-2"></span>
                    Now Live for Academic Year 2024-25
                  </div>
                  <h1 className="text-5xl font-headline font-black tracking-tighter sm:text-6xl xl:text-7xl/none text-foreground">
                    Empowering <span className="text-primary italic">Education</span> through Technology.
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground text-lg md:text-xl leading-relaxed">
                    A unified, high-performance ecosystem for students and faculty. Experience the future of campus management today.
                  </p>
                </div>
                <div className="flex flex-col gap-4 min-[400px]:flex-row">
                  <Button asChild size="lg" className="rounded-full h-14 px-8 text-lg font-bold shadow-xl shadow-primary/30 hover:translate-y-[-2px] transition-all">
                    <Link href="/login" className="flex items-center">
                      Get Started <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                  <Button variant="outline" size="lg" className="rounded-full h-14 px-8 text-lg font-bold border-2 hover:bg-secondary/50">
                    <Link href="#features">Learn More</Link>
                  </Button>
                </div>
                <div className="flex items-center gap-6 pt-4 border-t border-border/50">
                   <div className="flex flex-col">
                     <span className="text-2xl font-black text-primary">15k+</span>
                     <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Active Students</span>
                   </div>
                   <div className="w-px h-10 bg-border/50"></div>
                   <div className="flex flex-col">
                     <span className="text-2xl font-black text-primary">98%</span>
                     <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Satisfaction</span>
                   </div>
                </div>
              </div>
              <div className="relative animate-in fade-in zoom-in-95 duration-1000 delay-200">
                <div className="absolute -inset-4 bg-gradient-to-tr from-primary/10 via-accent/10 to-transparent blur-3xl rounded-[3rem]" />
                <div className="relative aspect-[4/3] overflow-hidden rounded-[2.5rem] shadow-2xl border-[12px] border-white/50 backdrop-blur">
                  {heroImage && (
                    <Image
                      src={heroImage.imageUrl}
                      alt={heroImage.description}
                      fill
                      className="object-cover"
                      data-ai-hint={heroImage.imageHint}
                      priority
                    />
                  )}
                  <div className="absolute bottom-6 left-6 right-6 p-4 bg-white/80 backdrop-blur-md rounded-2xl shadow-lg flex items-center gap-4">
                    <div className="h-12 w-12 rounded-full bg-accent flex items-center justify-center text-white">
                      <CheckCircle className="h-6 w-6" />
                    </div>
                    <div>
                      <p className="font-bold text-sm">Official Portal Verified</p>
                      <p className="text-xs text-muted-foreground">Certified by Megha Trust for Excellence</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="features" className="w-full py-24 bg-white">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="text-center space-y-4 mb-16 max-w-3xl mx-auto">
              <h2 className="text-4xl font-headline font-black tracking-tighter sm:text-5xl text-foreground">Why Choose Campus Connect?</h2>
              <p className="text-muted-foreground text-lg">
                We've built a platform that addresses the real-world needs of modern educational institutions.
              </p>
            </div>
            <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { icon: ShieldCheck, title: "Secure Data", desc: "Enterprise-grade encryption for all records.", color: "text-primary", bg: "bg-primary/5" },
                { icon: Zap, title: "Instant Updates", desc: "Real-time notifications for exams and events.", color: "text-accent", bg: "bg-accent/5" },
                { icon: Users, title: "Collaborative", desc: "Integrated forums and club management tools.", color: "text-primary", bg: "bg-primary/5" },
                { icon: GraduationCap, title: "Academic Hub", desc: "Centralized access to all learning materials.", color: "text-accent", bg: "bg-accent/5" }
              ].map((feature, i) => (
                <div key={i} className="group relative p-8 rounded-[2rem] border-transparent border-2 hover:border-primary/10 hover:bg-secondary/20 transition-all duration-300">
                  <div className={`p-4 rounded-2xl ${feature.bg} ${feature.color} w-fit mb-6 group-hover:scale-110 transition-transform`}>
                    <feature.icon className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{feature.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="w-full py-24 bg-primary text-primary-foreground overflow-hidden relative">
          <div className="absolute top-0 right-0 w-1/2 h-full bg-white/5 skew-x-12 transform translate-x-1/2" />
          <div className="container px-4 md:px-6 mx-auto relative z-10">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <h2 className="text-4xl font-headline font-black leading-tight sm:text-5xl">Ready to transform your campus life?</h2>
                <p className="text-primary-foreground/80 text-lg">
                  Join thousands of students and faculty members who are already using Megha Campus Connect to streamline their academic workflow.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button variant="secondary" size="lg" className="rounded-full h-14 px-10 font-bold shadow-xl">
                    Register Account
                  </Button>
                  <Button variant="outline" size="lg" className="rounded-full h-14 px-10 font-bold border-white/20 hover:bg-white/10 text-white">
                    Contact Support
                  </Button>
                </div>
              </div>
              <div className="hidden lg:block relative aspect-square">
                 <div className="absolute inset-0 bg-white/10 rounded-full animate-pulse" />
                 <div className="absolute inset-10 bg-white/10 rounded-full animate-pulse delay-75" />
                 <div className="absolute inset-20 bg-white/10 rounded-full animate-pulse delay-150" />
                 <div className="absolute inset-0 flex items-center justify-center">
                    <GraduationCap className="h-32 w-32 opacity-20" />
                 </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="w-full border-t py-12 bg-secondary/30">
        <div className="container px-4 md:px-6 mx-auto">
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4 mb-12">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <GraduationCap className="h-6 w-6 text-primary" />
                <span className="font-headline font-bold text-xl text-primary">Megha Campus</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Connecting education with innovation for a better academic future.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Portal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/login" className="hover:text-primary transition-colors">Student Login</Link></li>
                <li><Link href="/register" className="hover:text-primary transition-colors">Faculty Registration</Link></li>
                <li><Link href="#" className="hover:text-primary transition-colors">Admissions 2024</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="#" className="hover:text-primary transition-colors">IT Helpdesk</Link></li>
                <li><Link href="#" className="hover:text-primary transition-colors">FAQ</Link></li>
                <li><Link href="#" className="hover:text-primary transition-colors">Privacy Policy</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Contact</h4>
              <p className="text-sm text-muted-foreground">
                123 University Ave<br />
                Academic District, NY 10001<br />
                support@megha.edu
              </p>
            </div>
          </div>
          <div className="flex flex-col md:flex-row items-center justify-between pt-8 border-t border-border/50 gap-4">
            <p className="text-xs text-muted-foreground">© 2024 Megha Campus Connect. All rights reserved.</p>
            <div className="flex gap-6">
              <Link href="#" className="text-xs text-muted-foreground hover:text-primary">Twitter</Link>
              <Link href="#" className="text-xs text-muted-foreground hover:text-primary">LinkedIn</Link>
              <Link href="#" className="text-xs text-muted-foreground hover:text-primary">Instagram</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

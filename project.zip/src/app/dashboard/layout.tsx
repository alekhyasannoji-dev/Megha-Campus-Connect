'use client';

import { SidebarProvider, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { Bell, Search, Globe } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { AuthInitializer } from "@/components/auth-initializer"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { useState, useEffect } from "react"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const [language, setLanguage] = useState("English")

  // Persistence for language preference
  useEffect(() => {
    const savedLang = localStorage.getItem("campus_lang")
    if (savedLang) setLanguage(savedLang)
  }, [])

  const handleLanguageChange = (val: string) => {
    setLanguage(val)
    localStorage.setItem("campus_lang", val)
    // Optional: Refresh or notify components if needed
    window.dispatchEvent(new Event("languageChanged"))
  }

  return (
    <SidebarProvider>
      <div className="flex h-screen w-full overflow-hidden bg-background">
        <AuthInitializer />
        <DashboardSidebar />
        <SidebarInset className="flex flex-col flex-1 relative overflow-hidden bg-background">
          <header className="flex h-16 shrink-0 items-center justify-between gap-2 px-6 border-b bg-white/40 backdrop-blur-md sticky top-0 z-40">
            <div className="flex items-center gap-4">
              <SidebarTrigger />
              <div className="hidden md:flex relative max-w-sm w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search courses, events..." 
                  className="pl-10 h-9 bg-secondary/50 border-transparent focus:bg-white focus:border-primary/20 transition-all rounded-full"
                />
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 bg-secondary/30 px-3 py-1 rounded-full border border-transparent hover:border-primary/20 transition-all">
                <Globe className="h-4 w-4 text-muted-foreground" />
                <Select value={language} onValueChange={handleLanguageChange}>
                  <SelectTrigger className="h-7 border-none bg-transparent focus:ring-0 w-[100px] text-xs font-bold p-0 shadow-none">
                    <SelectValue placeholder="Language" />
                  </SelectTrigger>
                  <SelectContent className="rounded-xl shadow-xl">
                    <SelectItem value="English">English</SelectItem>
                    <SelectItem value="Hindi">हिन्दी (Hindi)</SelectItem>
                    <SelectItem value="Spanish">Español (Spanish)</SelectItem>
                    <SelectItem value="French">Français (French)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-primary transition-colors">
                <Bell className="h-5 w-5" />
                <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-accent border-2 border-white" />
              </Button>
              <div className="h-8 w-px bg-border mx-1" />
              <div className="flex items-center gap-2 pl-2">
                <div className="hidden sm:flex flex-col items-end mr-2">
                  <span className="text-sm font-semibold leading-none">Aryan Sharma</span>
                  <span className="text-xs text-muted-foreground">ID: #20241001</span>
                </div>
                <Avatar className="h-10 w-10 border-2 border-primary/20 cursor-pointer hover:ring-2 ring-primary/40 transition-all">
                  <AvatarImage src="https://picsum.photos/seed/aryan/100/100" />
                  <AvatarFallback>AS</AvatarFallback>
                </Avatar>
              </div>
            </div>
          </header>
          {/* CRITICAL: The main element is the primary scroll container */}
          <main id="main-content" className="flex-1 overflow-y-auto overflow-x-hidden p-6 md:p-8 lg:p-10 pb-40 scroll-smooth">
            <div className="max-w-7xl mx-auto min-h-full">
              {children}
            </div>
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}

"use client"

import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { User, Mail, Phone, MapPin, Building, Calendar, Camera, Shield, Save, Printer } from "lucide-react"

export default function ProfilePage() {
  const handlePrint = () => {
    window.print()
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col space-y-1">
          <h1 className="text-3xl font-headline font-bold tracking-tight text-foreground flex items-center gap-2">
            Profile Settings <User className="h-6 w-6 text-primary" />
          </h1>
          <p className="text-muted-foreground">Manage your personal information and contact details.</p>
        </div>
        <Button variant="outline" className="rounded-full gap-2 no-print" onClick={handlePrint}>
          <Printer className="h-4 w-4" /> Print Profile
        </Button>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        <div className="space-y-6">
          <Card className="border-none shadow-md overflow-hidden card">
            <div className="h-32 bg-primary relative no-print">
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
            </div>
            <CardContent className="pt-0 flex flex-col items-center md:-mt-16 -mt-0 relative z-10">
              <div className="relative group">
                <Avatar className="h-32 w-32 border-4 border-white shadow-xl cursor-pointer">
                  <AvatarImage src="https://picsum.photos/seed/aryan/200/200" />
                  <AvatarFallback className="text-2xl">AS</AvatarFallback>
                </Avatar>
                <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity no-print">
                  <Camera className="h-6 w-6 text-white" />
                </div>
              </div>
              <div className="text-center mt-4">
                <h3 className="text-xl font-bold">Aryan Sharma</h3>
                <p className="text-sm text-muted-foreground mb-2">B.Tech - Computer Science</p>
                <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20">Student ID: #20241001</Badge>
              </div>
            </CardContent>
            <CardFooter className="bg-secondary/20 p-4 border-t flex flex-col gap-3 no-print">
               <div className="flex items-center gap-2 text-xs text-muted-foreground">
                 <Shield className="h-3 w-3" /> Last login: 2 hours ago
               </div>
            </CardFooter>
          </Card>

          <Card className="border-none shadow-md card">
            <CardHeader className="p-4 pb-2">
              <CardTitle className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Quick Stats</CardTitle>
            </CardHeader>
            <CardContent className="p-4 pt-0 space-y-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Semester</span>
                <span className="font-bold">5th Semester</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Scholarship</span>
                <Badge variant="secondary" className="bg-green-100 text-green-700 hover:bg-green-100">Full Merit</Badge>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Adviser</span>
                <span className="font-bold">Dr. V. Rao</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-2 space-y-6">
          <Card className="border-none shadow-md card">
            <CardHeader>
              <CardTitle className="text-xl font-bold">Personal Information</CardTitle>
              <CardDescription className="no-print">Update your personal and contact information below.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="firstName" className="text-xs font-bold uppercase tracking-tight text-muted-foreground">First Name</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground no-print" />
                    <Input id="firstName" defaultValue="Aryan" className="pl-10 h-11 border-secondary" readOnly />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName" className="text-xs font-bold uppercase tracking-tight text-muted-foreground">Last Name</Label>
                  <Input id="lastName" defaultValue="Sharma" className="h-11 border-secondary" readOnly />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-xs font-bold uppercase tracking-tight text-muted-foreground">Email Address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground no-print" />
                  <Input id="email" type="email" defaultValue="aryan.sharma@megha.edu" className="pl-10 h-11 border-secondary" readOnly />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-xs font-bold uppercase tracking-tight text-muted-foreground">Phone Number</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground no-print" />
                    <Input id="phone" defaultValue="+91 98765 43210" className="pl-10 h-11 border-secondary" readOnly />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dob" className="text-xs font-bold uppercase tracking-tight text-muted-foreground">Date of Birth</Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground no-print" />
                    <Input id="dob" type="text" defaultValue="July 14, 2003" className="pl-10 h-11 border-secondary" readOnly />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address" className="text-xs font-bold uppercase tracking-tight text-muted-foreground">Residential Address</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground no-print" />
                  <textarea 
                    id="address" 
                    rows={3}
                    className="w-full rounded-md border border-secondary bg-background px-3 py-2 pl-10 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                    defaultValue="Hostel Block A, Megha Campus, New Delhi, India"
                    readOnly
                  />
                </div>
              </div>

              <div className="flex justify-end pt-4 no-print">
                <Button className="rounded-full px-8 gap-2 shadow-lg shadow-primary/20">
                  <Save className="h-4 w-4" /> Save Changes
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md border-l-4 border-l-accent card">
            <CardHeader>
              <CardTitle className="text-lg font-bold flex items-center gap-2">
                <Building className="h-5 w-5 text-accent" /> Academic Department
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <p><span className="font-bold">Faculty:</span> Engineering & Technology</p>
                <p><span className="font-bold">Program:</span> Bachelor of Technology</p>
                <p><span className="font-bold">Major:</span> Computer Science and Engineering</p>
                <p><span className="font-bold">Academic Year:</span> 2022 - 2026</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
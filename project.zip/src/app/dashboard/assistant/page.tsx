"use client"

import { useState, useRef, useEffect } from "react"
import { chatbotFAQAnswerer } from "@/ai/flows/chatbot-faq-answerer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MessageSquare, Send, Bot, User, Sparkles, Loader2, Info, RefreshCw, Languages } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"

type Message = {
  id: string
  role: "user" | "assistant"
  content: string
  status?: "sending" | "sent" | "error"
}

export default function AssistantPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Hello! I'm your Megha Campus Assistant. How can I help you today? You can ask me about admissions, course details, campus facilities, or exam schedules."
    }
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [currentLanguage, setCurrentLanguage] = useState("English")
  const viewportRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const savedLang = localStorage.getItem("campus_lang")
    if (savedLang) setCurrentLanguage(savedLang)

    const handleLangChange = () => {
      const newLang = localStorage.getItem("campus_lang")
      if (newLang) setCurrentLanguage(newLang)
    }

    window.addEventListener("languageChanged", handleLangChange)
    return () => window.removeEventListener("languageChanged", handleLangChange)
  }, [])

  useEffect(() => {
    if (viewportRef.current) {
      const scrollContainer = viewportRef.current;
      scrollContainer.scrollTo({
        top: scrollContainer.scrollHeight,
        behavior: "smooth"
      })
    }
  }, [messages, isLoading])

  const sendMessageWithRetry = async (question: string, retries = 1): Promise<string> => {
    try {
      const response = await chatbotFAQAnswerer({ 
        question, 
        language: currentLanguage 
      })
      if (!response || !response.answer) {
        throw new Error("Empty AI response")
      }
      return response.answer
    } catch (error) {
      console.warn(`Attempt failed, retries left: ${retries}`, error)
      if (retries > 0) {
        return sendMessageWithRetry(question, retries - 1)
      }
      throw error
    }
  }

  const handleSendMessage = async (e?: React.FormEvent) => {
    e?.preventDefault()
    if (!input.trim() || isLoading) return

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      status: "sent"
    }

    setMessages(prev => [...prev, userMsg])
    const currentInput = input
    setInput("")
    setIsLoading(true)

    try {
      const answer = await sendMessageWithRetry(currentInput)
      
      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: answer
      }
      
      setMessages(prev => [...prev, assistantMsg])
    } catch (error) {
      const fallbackMsg = {
        'English': "Hi! I'm currently offline, but I can still help with basic campus info through the dashboard links.",
        'Hindi': "नमस्ते! मैं अभी ऑफलाइन हूं, लेकिन मैं डैशबोर्ड लिंक के माध्यम से बुनियादी परिसर जानकारी में मदद कर सकता हूं।",
        'Spanish': "¡Hola! Actualmente estoy desconectado, pero aún puedo ayudar con información básica del campus a través de los enlaces del tablero.",
        'French': "Salut! Je suis actuellement hors ligne, mais je peux toujours vous aider avec des informations de base sur le campus via les liens du tableau de bord."
      }[currentLanguage] || "Connection error."

      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: fallbackMsg,
        status: "error"
      }
      setMessages(prev => [...prev, errorMsg])
    } finally {
      setIsLoading(false)
    }
  }

  const quickPrompts = {
    'English': ["Hi there!", "Admission dates for 2024?", "Hostel facilities", "Library hours"],
    'Hindi': ["नमस्ते!", "2024 के लिए प्रवेश तिथियां?", "छात्रावास की सुविधाएं", "पुस्तकालय का समय"],
    'Spanish': ["¡Hola!", "¿Fechas de admisión 2024?", "Instalaciones del albergue", "Horario de biblioteca"],
    'French': ["Salut!", "Dates d'admission 2024 ?", "Installations de l'auberge", "Heures de bibliothèque"]
  }[currentLanguage] || ["Hi!"]

  return (
    <div className="max-w-6xl mx-auto min-h-full flex flex-col space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col space-y-1">
        <h1 className="text-4xl font-headline font-black tracking-tight text-foreground flex items-center gap-3">
          Campus Assistant <Sparkles className="h-8 w-8 text-accent fill-accent/20" />
        </h1>
        <div className="flex items-center gap-2">
          <p className="text-muted-foreground text-lg">Instant answers powered by campus intelligence.</p>
          <div className="flex items-center gap-1.5 bg-primary/5 px-3 py-1 rounded-full border border-primary/10 text-[10px] font-black uppercase tracking-widest text-primary">
            <Languages className="h-3 w-3" /> {currentLanguage}
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-4 h-[calc(100vh-280px)] min-h-[550px]">
        <div className="lg:col-span-1 hidden lg:flex flex-col gap-4">
           <Card className="border-none shadow-md bg-white rounded-3xl overflow-hidden">
             <CardHeader className="p-5 pb-2">
               <CardTitle className="text-xs font-black uppercase tracking-widest text-muted-foreground">Quick Start</CardTitle>
             </CardHeader>
             <CardContent className="p-5 pt-2 flex flex-col gap-2">
               {quickPrompts.map((prompt, idx) => (
                 <Button 
                   key={idx}
                   variant="secondary" 
                   className="justify-start text-xs font-bold h-auto py-3 px-4 rounded-xl whitespace-normal text-left hover:bg-primary/5 hover:text-primary transition-colors border-transparent hover:border-primary/20 border" 
                   onClick={() => setInput(prompt)}
                   disabled={isLoading}
                 >
                   {prompt}
                 </Button>
               ))}
             </CardContent>
           </Card>
           
           <Card className="border-none shadow-md bg-primary text-primary-foreground rounded-3xl">
             <CardContent className="p-6 flex flex-col gap-3">
               <div className="h-10 w-10 rounded-2xl bg-white/20 flex items-center justify-center">
                 <Info className="h-5 w-5" />
               </div>
               <p className="text-sm font-black">AI Powered Help</p>
               <p className="text-xs leading-relaxed opacity-80 font-medium">
                 I can help you navigate campus policies, find departments, and check important dates in your preferred language.
               </p>
               <Button 
                 variant="secondary" 
                 size="sm" 
                 className="w-full mt-2 rounded-xl font-bold bg-white text-primary hover:bg-white/90"
                 onClick={() => setMessages([messages[0]])}
               >
                 <RefreshCw className="h-3 w-3 mr-2" /> Clear Chat
               </Button>
             </CardContent>
           </Card>
        </div>

        <Card className="lg:col-span-3 border-none shadow-xl flex flex-col overflow-hidden bg-white rounded-[2.5rem] relative">
          <header className="border-b bg-white/80 backdrop-blur-md p-6 relative z-10 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="relative">
                <Avatar className="h-14 w-14 border-4 border-primary/10 shadow-sm">
                  <AvatarFallback className="bg-primary text-primary-foreground font-black">
                    <Bot className="h-7 w-7" />
                  </AvatarFallback>
                </Avatar>
                <span className="absolute bottom-0 right-0 h-4 w-4 rounded-full bg-emerald-500 border-4 border-white" />
              </div>
              <div>
                <CardTitle className="text-xl font-black">Megha Bot</CardTitle>
                <CardDescription className="text-xs font-bold text-muted-foreground flex items-center gap-1 uppercase tracking-widest">
                  Online <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse ml-1" />
                </CardDescription>
              </div>
            </div>
          </header>
          
          <ScrollArea className="flex-1 px-6 py-8" viewportRef={viewportRef}>
            <div className="space-y-6 pb-6">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex gap-4 ${m.role === "user" ? "flex-row-reverse" : "flex-row"} animate-in fade-in slide-in-from-bottom-2 duration-300`}
                >
                  <Avatar className="h-10 w-10 shrink-0 border-2 border-white shadow-md">
                    {m.role === "assistant" ? (
                      <div className="h-full w-full bg-primary flex items-center justify-center text-primary-foreground">
                        <Bot className="h-5 w-5" />
                      </div>
                    ) : (
                      <div className="h-full w-full bg-secondary flex items-center justify-center text-secondary-foreground">
                        <User className="h-5 w-5" />
                      </div>
                    )}
                  </Avatar>
                  <div
                    className={`max-w-[80%] px-5 py-3.5 rounded-[1.5rem] text-sm leading-relaxed shadow-sm font-medium ${
                      m.role === "user"
                        ? "bg-primary text-primary-foreground rounded-tr-none"
                        : m.status === "error"
                        ? "bg-red-50 text-red-600 border border-red-100 rounded-tl-none"
                        : "bg-secondary/40 text-foreground rounded-tl-none"
                    }`}
                  >
                    {m.content}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex gap-4">
                  <Avatar className="h-10 w-10 shrink-0 border-2 border-white shadow-md">
                    <div className="h-full w-full bg-primary flex items-center justify-center text-primary-foreground">
                      <Bot className="h-5 w-5" />
                    </div>
                  </Avatar>
                  <div className="bg-secondary/40 text-foreground rounded-[1.5rem] rounded-tl-none px-6 py-4 shadow-sm flex items-center gap-3">
                    <Loader2 className="h-5 w-5 animate-spin text-primary" />
                    <span className="text-xs font-black text-muted-foreground uppercase tracking-widest">Thinking...</span>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          <footer className="p-6 bg-white border-t">
            <form onSubmit={handleSendMessage} className="flex gap-3 items-center">
              <div className="relative flex-1">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={currentLanguage === 'Hindi' ? "एक संदेश लिखें..." : currentLanguage === 'Spanish' ? "Escribe un mensaje..." : currentLanguage === 'French' ? "Écrivez un message..." : "Type a message..."}
                  className="w-full rounded-2xl h-14 border-2 border-secondary focus-visible:ring-primary/20 text-base px-6 font-bold bg-secondary/10"
                  disabled={isLoading}
                />
              </div>
              <Button 
                type="submit" 
                size="icon" 
                className="rounded-2xl h-14 w-14 shadow-xl hover:shadow-primary/30 bg-primary hover:scale-105 transition-transform"
                disabled={isLoading || !input.trim()}
              >
                <Send className="h-6 w-6" />
              </Button>
            </form>
          </footer>
        </Card>
      </div>
    </div>
  )
}


import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { BookOpen, FileText, Download, GraduationCap, Clock, CheckCircle, ChevronRight } from "lucide-react"

const courses = [
  { id: "MA201", name: "Advanced Mathematics", grade: "A", status: "Completed", credits: 4 },
  { id: "CS302", name: "Computer Architecture", grade: "A-", status: "Ongoing", credits: 3 },
  { id: "CS304", name: "Data Structures", grade: "B+", status: "Ongoing", credits: 4 },
  { id: "HU101", name: "Professional Ethics", grade: "A", status: "Completed", credits: 2 },
]

export default function AcademicsPage() {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col space-y-1">
        <h1 className="text-3xl font-headline font-bold tracking-tight text-foreground flex items-center gap-2">
          Academic Information <BookOpen className="h-6 w-6 text-primary" />
        </h1>
        <p className="text-muted-foreground">Manage your courses, view grades, and download materials.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="border-none shadow-md bg-primary text-primary-foreground overflow-hidden relative">
          <div className="absolute -bottom-4 -right-4 opacity-10">
            <GraduationCap className="h-24 w-24" />
          </div>
          <CardHeader>
            <CardTitle className="text-lg opacity-90">Current CGPA</CardTitle>
            <h3 className="text-4xl font-bold">3.84</h3>
          </CardHeader>
          <CardContent>
            <p className="text-xs opacity-80">Rank: Top 10% of class</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md bg-accent text-accent-foreground overflow-hidden relative">
          <div className="absolute -bottom-4 -right-4 opacity-10">
            <CheckCircle className="h-24 w-24" />
          </div>
          <CardHeader>
            <CardTitle className="text-lg opacity-90">Credits Earned</CardTitle>
            <h3 className="text-4xl font-bold">84 / 120</h3>
          </CardHeader>
          <CardContent>
            <p className="text-xs opacity-80">Progress: 70% Completed</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md bg-secondary text-secondary-foreground overflow-hidden relative">
          <div className="absolute -bottom-4 -right-4 opacity-10">
            <Clock className="h-24 w-24" />
          </div>
          <CardHeader>
            <CardTitle className="text-lg opacity-90">Academic Status</CardTitle>
            <h3 className="text-4xl font-bold">Good Stand</h3>
          </CardHeader>
          <CardContent>
            <p className="text-xs opacity-80">No pending backlogs</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="border-none shadow-md">
          <CardHeader>
            <CardTitle className="text-xl font-bold">Current Courses & Grades</CardTitle>
            <CardDescription>Performance summary for current and past semesters.</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Course Code</TableHead>
                  <TableHead>Course Name</TableHead>
                  <TableHead>Credits</TableHead>
                  <TableHead>Grade</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {courses.map((course) => (
                  <TableRow key={course.id}>
                    <TableCell className="font-mono text-xs">{course.id}</TableCell>
                    <TableCell className="font-medium">{course.name}</TableCell>
                    <TableCell>{course.credits}</TableCell>
                    <TableCell>
                      <Badge variant={course.grade === 'A' ? 'default' : 'secondary'} className="rounded-md">
                        {course.grade}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <Button variant="ghost" className="w-full mt-4 text-primary font-bold">
              View All Transcripts <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card className="border-none shadow-md">
            <CardHeader>
              <CardTitle className="text-xl font-bold flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Examination Schedule
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-3 border rounded-lg bg-red-50/30 border-red-100">
                <div className="space-y-1">
                  <p className="text-sm font-bold text-red-700">Final Semester Exams</p>
                  <p className="text-xs text-red-600">Starting Dec 20, 2024</p>
                </div>
                <Button size="sm" variant="outline" className="text-red-600 border-red-200 hover:bg-red-50 gap-2">
                  <Download className="h-3 w-3" /> Hall Ticket
                </Button>
              </div>
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="space-y-1">
                  <p className="text-sm font-bold">Internal Assessment 2</p>
                  <p className="text-xs text-muted-foreground">Results published</p>
                </div>
                <Button size="sm" variant="ghost" className="text-primary gap-2">
                  <ChevronRight className="h-3 w-3" /> View Results
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md">
            <CardHeader>
              <CardTitle className="text-xl font-bold">Recent Course Materials</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg group">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 bg-white rounded-md shadow-sm flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                      <FileText className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm font-bold">Unit_3_Graph_Theory.pdf</p>
                      <p className="text-[10px] text-muted-foreground">Discrete Math • 4.5 MB</p>
                    </div>
                  </div>
                  <Button size="icon" variant="ghost" className="rounded-full">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg group">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 bg-white rounded-md shadow-sm flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                      <FileText className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm font-bold">Lab_Ex6_Assembly.zip</p>
                      <p className="text-[10px] text-muted-foreground">Comp Architecture • 12 MB</p>
                    </div>
                  </div>
                  <Button size="icon" variant="ghost" className="rounded-full">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

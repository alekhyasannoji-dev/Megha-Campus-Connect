"use client"

import { useFirestore, useUser, useMemoFirebase, useCollection } from "@/firebase"
import { collectionGroup, query, where, orderBy } from "firebase/firestore"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Printer, Calendar, Download, Info, Loader2, ClipboardList } from "lucide-react"

export default function MyRegistrationsPage() {
  const { firestore } = useFirestore()
  const { user, isUserLoading } = useUser()

  const registrationsQuery = useMemoFirebase(() => {
    if (!firestore || !user) return null
    // Collection group query to find all registrations for this user across all events
    return query(
      collectionGroup(firestore, "registrations"),
      where("userId", "==", user.uid),
      orderBy("registrationDate", "desc")
    )
  }, [firestore, user])

  const { data: registrations, isLoading: isDataLoading } = useCollection(registrationsQuery)

  const handlePrint = (regId?: string) => {
    if (regId) {
      // Logic for printing a specific element could go here, but window.print()
      // combined with the CSS @media print is usually better for simplicity.
      // We can wrap the registration in a "print-only" wrapper temporarily if needed.
      window.print()
    } else {
      window.print()
    }
  }

  if (isUserLoading || isDataLoading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="space-y-8 pb-20 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-4xl font-headline font-black tracking-tight text-foreground flex items-center gap-3">
            My Registrations <ClipboardList className="h-8 w-8 text-primary" />
          </h1>
          <p className="text-muted-foreground text-lg">Manage and print your event registration receipts.</p>
        </div>
        <Button 
          variant="outline"
          className="rounded-full gap-2 no-print h-12 px-6 font-bold" 
          onClick={() => handlePrint()}
        >
          <Printer className="h-4 w-4" /> Print All Receipts
        </Button>
      </div>

      {registrations && registrations.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {registrations.map((reg) => (
            <Card key={reg.id} className="border-none shadow-md overflow-hidden flex flex-col bg-white card">
              <CardHeader className="p-6 pb-2">
                <div className="flex justify-between items-start mb-2">
                  <Badge variant="secondary" className="bg-primary/10 text-primary border-none">
                    Registered
                  </Badge>
                  <span className="text-[10px] text-muted-foreground flex items-center gap-1 font-bold">
                    <Calendar className="h-3 w-3" /> {new Date(reg.registrationDate).toLocaleDateString()}
                  </span>
                </div>
                <CardTitle className="text-xl font-black">
                  {reg.registrantName}
                </CardTitle>
                <CardDescription className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
                  Roll: {reg.rollNumber} • {reg.branch}
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6 pt-2 space-y-4 flex-1">
                <div className="space-y-1 bg-secondary/20 p-4 rounded-xl">
                  <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Contact Information</p>
                  <p className="text-sm font-medium">{reg.email}</p>
                  <p className="text-sm font-medium">{reg.phoneNumber}</p>
                </div>
                <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                  <Info className="h-3 w-3 text-primary" /> Registration ID: {reg.id.substring(0, 8)}
                </div>
              </CardContent>
              <CardFooter className="p-6 pt-0 border-t mt-auto bg-secondary/5 flex gap-2 no-print">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="flex-1 font-black text-primary hover:bg-primary/5 gap-2"
                  onClick={() => handlePrint(reg.id)}
                >
                  <Printer className="h-4 w-4" /> Print Receipt
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="rounded-full no-print"
                  onClick={() => handlePrint(reg.id)}
                >
                  <Download className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center p-20 text-center text-muted-foreground border-4 border-dashed rounded-[3rem] bg-secondary/10">
          <div className="h-24 w-24 rounded-full bg-secondary/20 flex items-center justify-center mb-6">
            <ClipboardList className="h-12 w-12 opacity-40 text-primary" />
          </div>
          <h2 className="text-2xl font-black text-foreground mb-2">No registrations found.</h2>
          <p className="text-muted-foreground max-w-sm">Join campus events and they will appear here for management.</p>
        </div>
      )}
    </div>
  )
}

"use client"

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { 
  BookOpen, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  TrendingUp, 
  Award, 
  ArrowRight,
  Bell,
  Search,
  ChevronRight,
  Star,
  Loader2
} from "lucide-react"
import Link from "next/link"
import { useFirestore, useCollection, useMemoFirebase } from "@/firebase"
import { collection, query } from "firebase/firestore"
import { useMemo } from "react"

export default function Dashboard() {
  const { firestore } = useFirestore()
  
  const feedbackQuery = useMemoFirebase(() => {
    if (!firestore) return null
    return query(collection(firestore, "feedback"))
  }, [firestore])

  const { data: feedbacks, isLoading: isFeedbackLoading } = useCollection(feedbackQuery)

  const averageRating = useMemo(() => {
    if (!feedbacks || feedbacks.length === 0) return "4.5" // Default high rating
    const sum = feedbacks.reduce((acc, curr) => acc + (curr.rating || 0), 0)
    return (sum / feedbacks.length).toFixed(1)
  }, [feedbacks])

  const stats = [
    { label: "Community Rating", value: averageRating, sub: `${feedbacks?.length || 0} reviews`, icon: Star, color: "text-amber-500", bg: "bg-amber-50" },
    { label: "Attendance", value: "92%", sub: "12/13 classes", icon: CheckCircle2, color: "text-emerald-600", bg: "bg-emerald-50" },
    { label: "Total Credits", value: "84/120", sub: "70% Progress", icon: Award, color: "text-accent", bg: "bg-accent/10" },
    { label: "Active Tasks", value: "4 Pending", sub: "Due this week", icon: Clock, color: "text-orange-600", bg: "bg-orange-50" },
  ]

  const upcomingClasses = [
    { time: "09:00 AM", subject: "Advanced Mathematics", room: "LT-4", tutor: "Dr. Rao", status: "Ongoing" },
    { time: "11:30 AM", subject: "Computer Architecture", room: "Lab-2", tutor: "Prof. Gupta", status: "Upcoming" },
    { time: "02:00 PM", subject: "Data Structures", room: "LT-1", tutor: "Ms. Verma", status: "Upcoming" },
  ]

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-4xl font-headline font-black tracking-tight text-foreground">Welcome back, Aryan!</h1>
          <p className="text-muted-foreground text-lg">Your academic summary for <span className="font-semibold text-foreground">Fall Semester 2024</span>.</p>
        </div>
        <div className="flex items-center gap-3">
           <Button variant="outline" className="rounded-full gap-2 border-2">
             <Calendar className="h-4 w-4" /> Academic Calendar
           </Button>
           <Button className="rounded-full gap-2 shadow-lg shadow-primary/20">
             <Bell className="h-4 w-4" /> Notifications
           </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.label} className="group border-none shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden relative">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="space-y-2">
                  <p className="text-sm font-bold text-muted-foreground uppercase tracking-wider">{stat.label}</p>
                  <h3 className="text-3xl font-black">{stat.value}</h3>
                  <p className="text-xs font-medium text-muted-foreground">{stat.sub}</p>
                </div>
                <div className={`p-4 rounded-2xl ${stat.bg} ${stat.color} group-hover:scale-110 transition-transform`}>
                  <stat.icon className="h-6 w-6" />
                </div>
              </div>
            </CardContent>
            <div className={`absolute bottom-0 left-0 h-1 bg-current opacity-20 w-full ${stat.color}`} />
          </Card>
        ))}
      </div>

      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-12">
        <Card className="lg:col-span-8 border-none shadow-md overflow-hidden bg-white">
          <CardHeader className="flex flex-row items-center justify-between pb-4 border-b">
            <div className="space-y-1">
              <CardTitle className="text-xl font-black">Course Progress</CardTitle>
              <CardDescription>Real-time performance across current enrollments</CardDescription>
            </div>
            <Button variant="ghost" size="sm" asChild className="text-primary hover:bg-primary/5">
              <Link href="/dashboard/academics" className="flex items-center gap-1 font-bold">
                Detailed Records <ChevronRight className="h-4 w-4" />
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="pt-6 space-y-8">
            {[
              { name: "Core Engineering", val: 90, grade: "A", color: "bg-primary" },
              { name: "Information Systems", val: 82, grade: "A-", color: "bg-accent" },
              { name: "Discrete Mathematics", val: 75, grade: "B+", color: "bg-primary" },
              { name: "Software Architecture", val: 88, grade: "A", color: "bg-accent" }
            ].map((course, i) => (
              <div key={i} className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`h-2 w-2 rounded-full ${course.color}`} />
                    <span className="font-bold text-sm">{course.name}</span>
                  </div>
                  <Badge variant="secondary" className="font-mono">{course.grade} (90%)</Badge>
                </div>
                <Progress value={course.val} className="h-2.5 bg-secondary/50" />
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="lg:col-span-4 border-none shadow-md bg-white">
          <CardHeader className="border-b pb-4">
            <CardTitle className="text-xl font-black flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              Today's Classes
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-4">
              {upcomingClasses.map((item, idx) => (
                <div key={idx} className="relative pl-6 before:absolute before:left-0 before:top-0 before:bottom-0 before:w-1 before:bg-primary/20 before:rounded-full group cursor-pointer">
                  <div className="flex items-start justify-between mb-1">
                    <span className="text-xs font-bold text-primary bg-primary/5 px-2 py-1 rounded">{item.time}</span>
                    <Badge variant={item.status === 'Ongoing' ? 'default' : 'outline'} className="text-[10px] h-5">
                      {item.status}
                    </Badge>
                  </div>
                  <h4 className="text-sm font-black group-hover:text-primary transition-colors">{item.subject}</h4>
                  <p className="text-xs text-muted-foreground">{item.tutor} • Room {item.room}</p>
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full mt-8 rounded-xl font-bold border-2">
              View Full Schedule
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        <Card className="border-none shadow-md bg-accent text-accent-foreground overflow-hidden relative group">
          <div className="absolute -bottom-6 -right-6 opacity-10 group-hover:scale-125 transition-transform duration-500">
            <Bell className="h-32 w-32" />
          </div>
          <CardHeader>
            <CardTitle className="text-xl font-black">Latest Update</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-white/10 backdrop-blur-md p-5 rounded-2xl border border-white/20">
              <Badge className="mb-3 bg-white text-accent hover:bg-white/90">Important</Badge>
              <h4 className="font-black text-lg mb-2 leading-tight text-white">Fall Exam Schedule Published</h4>
              <p className="text-sm text-accent-foreground/80 line-clamp-2">
                Download the official PDF for all engineering departments. Exams begin Dec 12.
              </p>
            </div>
            <Button variant="secondary" asChild className="w-full h-12 rounded-xl font-black shadow-lg">
              <Link href="/dashboard/announcements">Check Announcements</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 border-none shadow-md bg-white overflow-hidden">
          <CardHeader className="border-b">
            <CardTitle className="text-xl font-black">Recent Materials</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y">
              {[
                { title: "Lecture_Notes_Week12.pdf", sub: "Advanced Math", size: "2.4 MB", icon: "pdf" },
                { title: "Lab_Instructions_Arch.docx", sub: "Comp Architecture", size: "1.2 MB", icon: "doc" },
                { title: "Project_Proposal_Draft.zip", sub: "Software Eng", size: "15.0 MB", icon: "zip" }
              ].map((file, i) => (
                <div key={i} className="flex items-center justify-between p-4 hover:bg-secondary/20 transition-colors cursor-pointer group">
                  <div className="flex items-center gap-4">
                    <div className="h-10 w-10 rounded-xl bg-primary/5 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                      <BookOpen className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm font-black">{file.title}</p>
                      <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-widest">{file.sub} • {file.size}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

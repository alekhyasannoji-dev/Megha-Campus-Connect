
"use client"

import { useState } from "react"
import { useFirestore, useUser, useCollection, useMemoFirebase } from "@/firebase"
import { collection, query, orderBy } from "firebase/firestore"
import { addDocumentNonBlocking } from "@/firebase/non-blocking-updates"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Star, Send, Loader2, MessageSquare, Heart, Sparkles, CheckCircle2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

export default function FeedbackPage() {
  const { firestore } = useFirestore()
  const { user, isUserLoading } = useUser()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [rating, setRating] = useState(0)
  const [hoverRating, setHoverRating] = useState(0)

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    comment: ""
  })

  const feedbackQuery = useMemoFirebase(() => {
    if (!firestore) return null
    return query(collection(firestore, "feedback"), orderBy("createdAt", "desc"))
  }, [firestore])

  const { data: feedbacks, isLoading: isFeedbackLoading } = useCollection(feedbackQuery)

  const handleStarClick = (index: number) => {
    setRating(index)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!firestore || !user) return
    if (rating === 0) {
      toast({
        variant: "destructive",
        title: "Rating required",
        description: "Please select a star rating before submitting.",
      })
      return
    }

    setIsSubmitting(true)
    const feedbackRef = collection(firestore, "feedback")

    try {
      addDocumentNonBlocking(feedbackRef, {
        ...formData,
        rating,
        userId: user.uid,
        createdAt: new Date().toISOString()
      })

      toast({
        title: "Feedback Submitted!",
        description: "Thank you for your valuable feedback!",
      })
      
      setFormData({ name: "", email: "", comment: "" })
      setRating(0)
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Submission failed",
        description: "An unexpected error occurred. Please try again.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-20 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col space-y-2">
        <h1 className="text-4xl font-headline font-black tracking-tight text-foreground flex items-center gap-3">
          Voice of Megha <Heart className="h-8 w-8 text-pink-500 fill-pink-500/20" />
        </h1>
        <p className="text-muted-foreground text-lg">Help us shape the future of your campus digital home.</p>
      </div>

      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-5 space-y-6">
          <Card className="border-none shadow-2xl rounded-[2.5rem] overflow-hidden bg-white">
            <div className="bg-primary p-8 text-primary-foreground relative overflow-hidden">
               <div className="absolute top-0 right-0 p-4 opacity-10">
                 <Sparkles className="h-20 w-20" />
               </div>
               <h3 className="text-2xl font-black mb-2">Share Your Thoughts</h3>
               <p className="text-primary-foreground/80 font-medium">Every suggestion helps us improve.</p>
            </div>
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-4 text-center pb-4">
                  <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Rate your experience</Label>
                  <div className="flex items-center justify-center gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        className="transition-all duration-200 transform hover:scale-125 focus:outline-none"
                        onClick={() => handleStarClick(star)}
                        onMouseEnter={() => setHoverRating(star)}
                        onMouseLeave={() => setHoverRating(0)}
                      >
                        <Star 
                          className={`h-10 w-10 ${
                            (hoverRating || rating) >= star 
                            ? "fill-amber-400 text-amber-400" 
                            : "text-secondary fill-secondary/20"
                          }`} 
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="fb-name" className="text-xs font-black uppercase tracking-widest text-muted-foreground">Full Name</Label>
                    <Input 
                      id="fb-name"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Aryan Sharma"
                      className="h-12 rounded-2xl border-secondary focus:ring-primary/20 font-bold bg-secondary/5"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="fb-email" className="text-xs font-black uppercase tracking-widest text-muted-foreground">Academic Email</Label>
                    <Input 
                      id="fb-email"
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="aryan@megha.edu"
                      className="h-12 rounded-2xl border-secondary focus:ring-primary/20 font-bold bg-secondary/5"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="fb-comment" className="text-xs font-black uppercase tracking-widest text-muted-foreground">Your Suggestions</Label>
                    <Textarea 
                      id="fb-comment"
                      required
                      rows={4}
                      value={formData.comment}
                      onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
                      placeholder="What can we do better?"
                      className="rounded-2xl border-secondary focus:ring-primary/20 font-medium bg-secondary/5 resize-none"
                    />
                  </div>
                </div>

                <Button 
                  type="submit" 
                  disabled={isSubmitting || isUserLoading}
                  className="w-full h-14 rounded-2xl font-black text-lg shadow-xl shadow-primary/20 hover:scale-[1.02] transition-transform active:scale-95 bg-primary"
                >
                  {isSubmitting ? (
                    <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Sending...</>
                  ) : (
                    <><Send className="mr-2 h-5 w-5" /> Submit Feedback</>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-7 space-y-6">
          <Tabs defaultValue="recent" className="w-full">
            <div className="flex items-center justify-between mb-6">
              <TabsList className="bg-secondary/50 p-1 rounded-full border border-transparent">
                <TabsTrigger value="recent" className="rounded-full px-8 font-bold">Recent Feedback</TabsTrigger>
                <TabsTrigger value="stats" className="rounded-full px-8 font-bold">Insights</TabsTrigger>
              </TabsList>
              <Badge variant="outline" className="h-10 px-4 rounded-full border-2 font-black text-primary bg-white">
                {feedbacks?.length || 0} Submissions
              </Badge>
            </div>

            <TabsContent value="recent" className="space-y-4">
              {isFeedbackLoading ? (
                <div className="flex items-center justify-center p-20">
                  <Loader2 className="h-12 w-12 animate-spin text-primary opacity-20" />
                </div>
              ) : feedbacks && feedbacks.length > 0 ? (
                <div className="grid gap-4">
                  {feedbacks.map((item) => (
                    <Card key={item.id} className="border-none shadow-md hover:shadow-lg transition-shadow bg-white rounded-3xl group">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <Avatar className="h-12 w-12 border-2 border-primary/10">
                            <AvatarFallback className="bg-primary/5 text-primary font-black uppercase">
                              {item.name.substring(0, 2)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center justify-between">
                              <h4 className="font-black text-lg">{item.name}</h4>
                              <div className="flex items-center gap-0.5">
                                {[1, 2, 3, 4, 5].map((s) => (
                                  <Star key={s} className={`h-3 w-3 ${s <= item.rating ? "fill-amber-400 text-amber-400" : "text-secondary fill-secondary/20"}`} />
                                ))}
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground leading-relaxed font-medium line-clamp-2 italic group-hover:line-clamp-none transition-all">
                              "{item.comment}"
                            </p>
                            <div className="flex items-center justify-between pt-2">
                              <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
                                {new Date(item.createdAt).toLocaleDateString()}
                              </span>
                              <Badge variant="secondary" className="bg-emerald-50 text-emerald-600 border-none flex items-center gap-1">
                                <CheckCircle2 className="h-3 w-3" /> Received
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center p-20 text-center text-muted-foreground border-4 border-dashed rounded-[3rem] bg-secondary/10">
                  <MessageSquare className="h-16 w-16 mb-6 opacity-20 text-primary" />
                  <h3 className="text-2xl font-black text-foreground mb-2">No feedback yet</h3>
                  <p className="max-w-xs">Be the first to share your experience with us!</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="stats">
              <div className="grid gap-6 md:grid-cols-2">
                <Card className="border-none shadow-xl bg-primary text-primary-foreground rounded-[2.5rem] overflow-hidden relative">
                   <div className="absolute -bottom-10 -right-10 opacity-10">
                     <Star className="h-40 w-40 fill-white" />
                   </div>
                   <CardHeader>
                     <CardTitle className="text-xs font-black uppercase tracking-widest opacity-80">Average Satisfaction</CardTitle>
                   </CardHeader>
                   <CardContent className="pb-10">
                      <h2 className="text-7xl font-black">
                        {feedbacks && feedbacks.length > 0 
                          ? (feedbacks.reduce((a, b) => a + (b.rating || 0), 0) / feedbacks.length).toFixed(1)
                          : "4.5"
                        }
                      </h2>
                      <div className="flex gap-1 mt-2">
                        {[1, 2, 3, 4, 5].map(i => <Star key={i} className="h-5 w-5 fill-white text-white" />)}
                      </div>
                   </CardContent>
                </Card>

                <Card className="border-none shadow-xl bg-white rounded-[2.5rem] flex flex-col items-center justify-center p-8 text-center">
                   <div className="h-20 w-20 rounded-3xl bg-pink-50 flex items-center justify-center mb-4">
                     <Heart className="h-10 w-10 text-pink-500 fill-pink-500/20" />
                   </div>
                   <h3 className="text-2xl font-black mb-2">Community Growth</h3>
                   <p className="text-muted-foreground text-sm font-medium">
                     Your feedback has led to 12 platform updates this semester alone. Keep 'em coming!
                   </p>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

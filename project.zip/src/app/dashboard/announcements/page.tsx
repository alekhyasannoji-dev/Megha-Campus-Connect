
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Megaphone, Calendar, Users, Info, ExternalLink, Bookmark } from "lucide-react"
import Image from "next/image"

const announcements = [
  {
    id: 1,
    title: "Annual Cultural Fest - 'Megha Utsav' 2024",
    category: "Event",
    date: "Dec 15-18, 2024",
    content: "Prepare for the biggest campus celebration! Registrations for talent hunts, musical nights, and dance competitions are now open.",
    image: "https://picsum.photos/seed/fest/600/300",
    author: "Cultural Committee",
    isImportant: true
  },
  {
    id: 2,
    title: "Workshop: Introduction to AI & ML",
    category: "Workshop",
    date: "Nov 22, 2024",
    content: "Join us for a hands-on workshop on Artificial Intelligence and Machine Learning featuring experts from top tech industries.",
    image: "https://picsum.photos/seed/ai/600/300",
    author: "Tech Club",
    isImportant: false
  },
  {
    id: 3,
    title: "Campus Wi-Fi Maintenance Schedule",
    category: "Maintenance",
    date: "Nov 15, 2024",
    content: "The campus-wide Wi-Fi network will be down for scheduled maintenance between 12:00 AM and 04:00 AM on Sunday.",
    author: "IT Department",
    isImportant: false
  }
]

export default function AnnouncementsPage() {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-headline font-bold tracking-tight text-foreground flex items-center gap-2">
            Campus Feed <Megaphone className="h-6 w-6 text-primary" />
          </h1>
          <p className="text-muted-foreground">Official announcements and upcoming events for the Megha community.</p>
        </div>
        <Button className="rounded-full gap-2">
          <Bookmark className="h-4 w-4" /> Saved Posts
        </Button>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="bg-secondary/50 p-1 rounded-full mb-8">
          <TabsTrigger value="all" className="rounded-full px-8">All Feed</TabsTrigger>
          <TabsTrigger value="official" className="rounded-full px-8">Official</TabsTrigger>
          <TabsTrigger value="events" className="rounded-full px-8">Events</TabsTrigger>
          <TabsTrigger value="clubs" className="rounded-full px-8">Club News</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {announcements.map((item) => (
              <Card key={item.id} className="border-none shadow-md hover:shadow-xl transition-all overflow-hidden flex flex-col group">
                {item.image && (
                  <div className="relative aspect-video overflow-hidden">
                    <Image 
                      src={item.image} 
                      alt={item.title} 
                      fill 
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    {item.isImportant && (
                      <Badge className="absolute top-3 left-3 bg-red-500 text-white border-none shadow-lg">Important</Badge>
                    )}
                  </div>
                )}
                <CardHeader className="p-5 pb-2">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="secondary" className="bg-primary/10 text-primary border-none">
                      {item.category}
                    </Badge>
                    <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                      <Calendar className="h-3 w-3" /> {item.date}
                    </span>
                  </div>
                  <CardTitle className="text-lg font-bold leading-tight group-hover:text-primary transition-colors">
                    {item.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-5 pt-0 flex-1">
                  <p className="text-sm text-muted-foreground line-clamp-3 leading-relaxed">
                    {item.content}
                  </p>
                </CardContent>
                <CardFooter className="p-5 pt-0 flex items-center justify-between border-t mt-auto bg-secondary/10">
                  <span className="text-xs font-medium text-muted-foreground">By {item.author}</span>
                  <Button variant="ghost" size="sm" className="text-primary hover:text-primary hover:bg-primary/5 p-0 h-auto font-bold">
                    Read More <ExternalLink className="ml-1 h-3 w-3" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        {/* Placeholder contents for other tabs */}
        <TabsContent value="official" className="p-12 text-center text-muted-foreground border-2 border-dashed rounded-xl bg-secondary/20">
          <Info className="h-12 w-12 mx-auto mb-4 opacity-20" />
          <p>Filtered official announcements will appear here.</p>
        </TabsContent>
        <TabsContent value="events" className="p-12 text-center text-muted-foreground border-2 border-dashed rounded-xl bg-secondary/20">
          <Calendar className="h-12 w-12 mx-auto mb-4 opacity-20" />
          <p>Upcoming campus events will be listed here.</p>
        </TabsContent>
        <TabsContent value="clubs" className="p-12 text-center text-muted-foreground border-2 border-dashed rounded-xl bg-secondary/20">
          <Users className="h-12 w-12 mx-auto mb-4 opacity-20" />
          <p>News from registered student clubs will show up here.</p>
        </TabsContent>
      </Tabs>
    </div>
  )
}

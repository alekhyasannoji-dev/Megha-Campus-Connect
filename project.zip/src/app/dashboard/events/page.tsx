"use client"

import { useState } from "react"
import { useFirestore, useCollection, useUser, useMemoFirebase } from "@/firebase"
import { collection, query, orderBy } from "firebase/firestore"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Plus, Info, MapPin, User as UserIcon, Loader2, Printer } from "lucide-react"
import Image from "next/image"
import { AddEventDialog } from "@/components/events/add-event-dialog"
import { RegisterEventDialog } from "@/components/events/register-event-dialog"

export default function EventsPage() {
  const { firestore } = useFirestore()
  const { user, isUserLoading } = useUser()
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedEvent, setSelectedEvent] = useState<any>(null)

  const eventsQuery = useMemoFirebase(() => {
    if (!firestore) return null
    // Ordered by date to show upcoming events first
    return query(collection(firestore, "events"), orderBy("date", "asc"))
  }, [firestore])

  const { data: events, isLoading: isEventsLoading } = useCollection(eventsQuery)

  const handlePrintSchedule = () => {
    window.print()
  }

  if (isEventsLoading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="space-y-8 pb-20 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-4xl font-headline font-black tracking-tight text-foreground flex items-center gap-3">
            Campus Events <Calendar className="h-8 w-8 text-primary" />
          </h1>
          <p className="text-muted-foreground text-lg">Real-time updates on campus happenings.</p>
        </div>
        <div className="flex items-center gap-3 no-print">
          <Button 
            variant="outline"
            className="rounded-full gap-2 h-14 px-6 font-bold" 
            onClick={handlePrintSchedule}
          >
            <Printer className="h-4 w-4" /> Print Schedule
          </Button>
          <Button 
            size="lg"
            className="rounded-full gap-2 shadow-xl shadow-primary/20 hover:scale-105 transition-transform shrink-0 bg-primary h-14 px-8 font-bold" 
            onClick={() => setIsAddDialogOpen(true)}
            disabled={isUserLoading}
          >
            {isUserLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Plus className="h-5 w-5" />} Add Event
          </Button>
        </div>
      </div>

      {events && events.length > 0 ? (
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {events.map((event) => (
            <Card 
              key={event.id} 
              className="group cursor-pointer border-none shadow-md hover:shadow-2xl transition-all duration-300 overflow-hidden flex flex-col bg-white border border-transparent hover:border-primary/10 relative z-10 card"
              onClick={() => setSelectedEvent(event)}
            >
              <div className="relative aspect-video overflow-hidden no-print">
                <Image 
                  src={event.imageUrl || "https://picsum.photos/seed/event/600/400"} 
                  alt={event.name} 
                  fill 
                  className="object-cover group-hover:scale-110 transition-transform duration-700"
                  data-ai-hint="campus event"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-40 group-hover:opacity-60 transition-opacity" />
                <Badge className="absolute top-4 left-4 bg-white/95 text-primary border-none shadow-lg backdrop-blur-md px-3 py-1 font-bold z-20">
                  {new Date(event.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                </Badge>
              </div>
              
              <CardHeader className="p-6 pb-2">
                <div className="hidden print-only text-xs font-bold text-primary mb-2">
                  Scheduled for: {new Date(event.date).toLocaleDateString()} at {new Date(event.date).toLocaleTimeString()}
                </div>
                <CardTitle className="text-xl font-black leading-tight group-hover:text-primary transition-colors line-clamp-2 min-h-[3rem]">
                  {event.name}
                </CardTitle>
              </CardHeader>
              
              <CardContent className="p-6 pt-0 flex-1">
                <p className="text-sm text-muted-foreground line-clamp-3 leading-relaxed mb-6 font-medium">
                  {event.description}
                </p>
                <div className="flex flex-col gap-3 text-[10px] text-muted-foreground font-bold uppercase tracking-widest">
                  <span className="flex items-center gap-2">
                    <MapPin className="h-3 w-3 text-primary" /> Campus Venue
                  </span>
                  <span className="flex items-center gap-2">
                    <UserIcon className="h-3 w-3 text-primary" /> Open to All
                  </span>
                </div>
              </CardContent>
              
              <CardFooter className="p-6 pt-0 border-t mt-auto bg-secondary/5 flex justify-end no-print">
                <Button variant="link" className="text-primary font-black p-0 h-auto group-hover:translate-x-1 transition-transform">
                  Register Now
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center p-20 text-center text-muted-foreground border-4 border-dashed rounded-[3rem] bg-secondary/10">
          <div className="h-24 w-24 rounded-full bg-secondary/20 flex items-center justify-center mb-6">
            <Info className="h-12 w-12 opacity-40 text-primary" />
          </div>
          <h2 className="text-2xl font-black text-foreground mb-2">No events scheduled.</h2>
          <p className="text-muted-foreground max-w-sm mb-8">Be the first to host an event for the Megha community!</p>
          <Button 
            className="rounded-full h-12 px-8 font-bold shadow-lg no-print" 
            onClick={() => setIsAddDialogOpen(true)}
            disabled={isUserLoading}
          >
             Host Now
          </Button>
        </div>
      )}

      <AddEventDialog 
        open={isAddDialogOpen} 
        onOpenChange={setIsAddDialogOpen} 
      />

      {selectedEvent && (
        <RegisterEventDialog
          event={selectedEvent}
          open={!!selectedEvent}
          onOpenChange={(open) => !open && setSelectedEvent(null)}
        />
      )}
    </div>
  )
}

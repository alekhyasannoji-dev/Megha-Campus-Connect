
"use client"

import Link from "next/link"
import { GraduationCap, ArrowRight, UserPlus, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function RegisterPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4 py-12">
      <Link href="/" className="flex items-center gap-2 mb-8 group">
        <div className="bg-primary p-2 rounded-xl group-hover:scale-110 transition-transform shadow-lg">
          <GraduationCap className="h-8 w-8 text-primary-foreground" />
        </div>
        <span className="font-headline font-bold text-2xl tracking-tight text-primary">Megha Campus Connect</span>
      </Link>

      <Card className="w-full max-w-lg border-none shadow-2xl animate-in zoom-in-95 duration-500">
        <CardHeader className="space-y-1 text-center pb-8">
          <div className="mx-auto w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center text-accent mb-4">
             <UserPlus className="h-6 w-6" />
          </div>
          <CardTitle className="text-3xl font-headline font-bold">Create Account</CardTitle>
          <CardDescription>Join the Megha community today</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="firstName" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">First Name</Label>
              <Input id="firstName" placeholder="Aryan" className="h-12 border-secondary" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lastName" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Last Name</Label>
              <Input id="lastName" placeholder="Sharma" className="h-12 border-secondary" />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="email" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Academic Email</Label>
            <Input id="email" type="email" placeholder="name@megha.edu" className="h-12 border-secondary" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="role" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Portal Role</Label>
            <Select>
              <SelectTrigger className="h-12 border-secondary">
                <SelectValue placeholder="Select your role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="student">Student</SelectItem>
                <SelectItem value="faculty">Faculty Member</SelectItem>
                <SelectItem value="staff">Administrative Staff</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
             <div className="space-y-2">
              <Label htmlFor="password" title="Set account password" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Password</Label>
              <Input id="password" type="password" className="h-12 border-secondary" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm" title="Confirm account password" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Confirm Password</Label>
              <Input id="confirm" type="password" className="h-12 border-secondary" />
            </div>
          </div>

          <Button asChild className="w-full h-12 text-base rounded-full shadow-lg shadow-primary/20 mt-4">
            <Link href="/dashboard">
              Register Account <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </CardContent>
        <CardFooter className="flex flex-col gap-4 border-t bg-secondary/20 p-6">
          <p className="text-sm text-center text-muted-foreground">
            Already have an account?{" "}
            <Link href="/login" className="text-primary font-bold hover:underline">Log in</Link>
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
              <CheckCircle2 className="h-3 w-3 text-green-500" /> Verify with ID
            </div>
            <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
              <CheckCircle2 className="h-3 w-3 text-green-500" /> Data Protection
            </div>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}

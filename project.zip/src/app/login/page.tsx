
"use client"

import Link from "next/link"
import { GraduationCap, ArrowRight, ShieldCheck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function LoginPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <Link href="/" className="flex items-center gap-2 mb-8 group">
        <div className="bg-primary p-2 rounded-xl group-hover:scale-110 transition-transform shadow-lg">
          <GraduationCap className="h-8 w-8 text-primary-foreground" />
        </div>
        <span className="font-headline font-bold text-2xl tracking-tight text-primary">Megha Campus Connect</span>
      </Link>

      <Card className="w-full max-w-md border-none shadow-2xl animate-in zoom-in-95 duration-500">
        <CardHeader className="space-y-1 text-center pb-8">
          <CardTitle className="text-3xl font-headline font-bold">Portal Access</CardTitle>
          <CardDescription>Enter your credentials to access your dashboard</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="id" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">University ID</Label>
            <Input id="id" placeholder="e.g. 20241001" className="h-12 border-secondary focus:ring-primary/20" />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="password" title="Enter your portal password" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Password</Label>
              <Link href="#" className="text-xs font-medium text-primary hover:underline">Forgot password?</Link>
            </div>
            <Input id="password" type="password" className="h-12 border-secondary focus:ring-primary/20" />
          </div>
          <Button asChild className="w-full h-12 text-base rounded-full shadow-lg shadow-primary/20 hover:translate-y-[-1px] transition-all">
            <Link href="/dashboard">
              Login to Portal <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </CardContent>
        <CardFooter className="flex flex-col gap-4 border-t bg-secondary/20 p-6">
          <p className="text-sm text-center text-muted-foreground">
            Don't have an account?{" "}
            <Link href="/register" className="text-primary font-bold hover:underline">Register now</Link>
          </p>
          <div className="flex items-center justify-center gap-2 text-[10px] text-muted-foreground">
            <ShieldCheck className="h-3 w-3" /> Secure SSL Encryption Protected
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
